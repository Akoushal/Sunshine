//
//  SunshineTests.swift
//  SunshineTests
//
//  Created by Kazuya Shida on 2018/07/19.
//  Copyright © 2018 Unifa. All rights reserved.
//

import XCTest
@testable import Sunshine

class SunshineTests: XCTestCase {
    
    var srt: DataService?
    
    override func setUp() {
        super.setUp()
        srt = DataService()
    }
    
    override func tearDown() {
        srt = nil
        super.tearDown()
    }
    
    func test_ControllerHasTableView() {
        guard let controller = UIStoryboard(name: "Main", bundle: Bundle(for: ViewController.self)).instantiateViewController(withIdentifier: "ViewController") as? ViewController else {
            return XCTFail("Could not instantiate ViewController from main storyboard")
        }
        
        controller.loadViewIfNeeded()
        
        XCTAssertNotNil(controller.weatherListTableView,
                        "Controller should have a tableview")
    }
    
    func test_tableViewHasDataSource() {
        guard let controller = UIStoryboard(name: "Main", bundle: Bundle(for: ViewController.self)).instantiateViewController(withIdentifier: "ViewController") as? ViewController else {
            return XCTFail("Could not instantiate ViewController from main storyboard")
        }
        XCTAssertNotNil(controller.weatherListTableView.dataSource)
    }
    
    func test_tableViewConformsToTableViewDataSourceProtocol() {
        guard let controller = UIStoryboard(name: "Main", bundle: Bundle(for: ViewController.self)).instantiateViewController(withIdentifier: "ViewController") as? ViewController else {
            return XCTFail("Could not instantiate ViewController from main storyboard")
        }
        XCTAssertTrue(controller.conforms(to: UITableViewDataSource.self))
        XCTAssertTrue(controller.responds(to: #selector(controller.tableView(_:numberOfRowsInSection:))))
        XCTAssertTrue(controller.responds(to: #selector(controller.tableView(_:cellForRowAt:))))
    }
    
    func test_fetchWeatherData() {
        // Given Apiservice
        let srt = self.srt!
        
        // When fetch data
        let expect = XCTestExpectation(description: "callback")
        
        srt.requestFetchWeather { (weatherData, error) in
            expect.fulfill()
            XCTAssertEqual(weatherData?.list?.count, 16)
            for list in weatherData?.list ?? [] {
                XCTAssertNotNil(list.dt)
            }
        }
        
        wait(for: [expect], timeout: 10.0)
    }
}
