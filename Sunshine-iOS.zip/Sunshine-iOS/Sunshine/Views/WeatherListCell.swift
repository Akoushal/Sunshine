//
//  WeatherListCell.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/04.
//  Copyright © 2019 Unifa. All rights reserved.
//

import UIKit
import SDWebImage

class WeatherListCell: UITableViewCell {
    
    @IBOutlet weak var weatherConditionImgView: UIImageView!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var maxTempLbl: UILabel!
    @IBOutlet weak var weatherConditionLbl: UILabel!
    @IBOutlet weak var minTempLbl: UILabel!
    private let utils = Utilities()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
    }
    
    func configure(listObj: List) {
        guard let weather = listObj.weather?.first, let dt = listObj.dt, let maxTemp = listObj.temp?.max, let minTemp = listObj.temp?.min else { return}
        maxTempLbl.text = utils.convertKelvinToDegreeCelsius(temp: maxTemp)
        minTempLbl.text = utils.convertKelvinToDegreeCelsius(temp: minTemp)
        dateLbl.text = utils.convertDateStampToDateString(dt: dt)
        if let main = weather.main {
            weatherConditionLbl.text = main
            let iconName = getIconName(str: main)
            weatherConditionImgView.image = UIImage(named: iconName)
        }
        
        //To fetch the icon from the OpenWeatherApi
        //guard let icon = weather.icon else { return}
        //weatherConditionImgView.sd_setImage(with: URL(string: Configuration.WeatherIconImageBaseURL + icon + Configuration.ImageExtension), completed: nil)
    }
    
    func getIconName(str: String) -> String {
        switch str {
        case WeatherCondition.Rain.rawValue:
            return "icRain"
        case WeatherCondition.Clouds.rawValue:
            return "icCloudy"
        case WeatherCondition.Clear.rawValue:
            return "icClear"
        case WeatherCondition.Snow.rawValue:
            return "icSnow"
        case WeatherCondition.Storm.rawValue:
            return "icStorm"
        case WeatherCondition.Fog.rawValue:
            return "icFog"
        default:
            return ""
        }
    }
}
