//
//  Utilities.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/10.
//  Copyright © 2019 Unifa. All rights reserved.
//

import Foundation

class Utilities {
    //Convert Temperature to Degree Celsius
    func convertKelvinToDegreeCelsius(temp: Double) -> String {
        let temperatureInCelsius = temp - 273.15
        return String(format: "%.0f °C", temperatureInCelsius)
    }
    
    //Convert TimeStamp to Japanese format DateString
    func convertDateStampToDateString(dt: Double) -> String {
        let date = Date(timeIntervalSince1970: dt)
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone(abbreviation: "JST") //Set timezone that you want
        dateFormatter.locale = Locale(identifier: "ja_JP")//For Japanese Locale
        dateFormatter.timeStyle = .none
        dateFormatter.dateStyle = .full
        let strDate = dateFormatter.string(from: date)
        return strDate
    }
}
