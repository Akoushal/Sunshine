//
//  ViewController.swift
//  Sunshine
//
//  Created by Kazuya Shida on 2018/07/19.
//  Copyright © 2018 Unifa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView?
    
    lazy var weatherListTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = self
        tableView.delegate = self
        tableView.alpha = 0.0
        tableView.register(UINib(nibName: HeaderView.uniqueIdentifier, bundle: nil), forHeaderFooterViewReuseIdentifier: HeaderView.uniqueIdentifier)
        tableView.register(UINib(nibName: CellIdentifiers.weatherListCell, bundle: nil), forCellReuseIdentifier: CellIdentifiers.weatherListCell)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 100
        return tableView
    }()
    
    // MARK: - Injection
    let viewModel = WeatherViewModel(dataService: DataService())
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = Titles.title
        setUpNavBarAttributes()
        setUpSubviews()
        attemptFetchWeather()
    }
    
    private func setUpNavBarAttributes() {
        navigationController?.navigationBar.barTintColor = UIColor(red: 80/255, green: 183/255, blue: 242/255, alpha: 1.0)
        navigationController?.navigationBar.tintColor = .white
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        navigationController?.navigationBar.isTranslucent = false
    }
    
    private func setUpSubviews() {
        view.addSubview(weatherListTableView)
        
        // Setting Constraints for the tableview
        weatherListTableView.edgesAnchorEqualTo(destinationView: view).activate()
    }
    
    func attemptFetchWeather() {
        viewModel.fetchWeather()
        
        viewModel.updateLoadingStatus = {
            let _ = self.viewModel.isLoading ? self.activityIndicatorStart() : self.activityIndicatorStop()
        }
        
        viewModel.showAlertClosure = {
            if let error = self.viewModel.error {
                print(error.localizedDescription)
            }
        }
        
        viewModel.didFinishFetch = {
            //Update UI
            self.weatherListTableView.alpha = 1.0
            self.weatherListTableView.reloadData()
        }
    }
    
    // MARK: - UI Setup
    private func activityIndicatorStart() {
        // Code for show activity indicator view
        activityIndicator?.startAnimating()
    }
    
    private func activityIndicatorStop() {
        // Code for stop activity indicator view
        activityIndicator?.stopAnimating()
    }
}

// MARK: - UITableView Datasource

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //Tableview displays data of future dates only
        return viewModel.weatherList.count - 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.weatherListCell, for: indexPath) as? WeatherListCell else {
            return UITableViewCell()
        }
        cell.configure(listObj: viewModel.weatherList[indexPath.row + 1])
        return cell
    }
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return CGFloat(Configuration.HeaderViewHeight)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let view = tableView.dequeueReusableHeaderFooterView(withIdentifier: HeaderView.uniqueIdentifier) as? HeaderView else {
            return nil
        }
        view.setUp(with: viewModel.weatherList.first)
        return view
    }
}


