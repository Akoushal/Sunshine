//
//  Constants.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/06.
//  Copyright © 2019 Unifa. All rights reserved.
//

import Foundation

enum Titles {
    static let title = "Sunshine"
}

enum CellIdentifiers {
    static let weatherListCell = "WeatherListCell"
}
