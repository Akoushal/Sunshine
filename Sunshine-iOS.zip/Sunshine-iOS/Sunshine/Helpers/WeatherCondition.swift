//
//  WeatherCondition.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/10.
//  Copyright © 2019 Unifa. All rights reserved.
//

import Foundation

enum WeatherCondition: String {
    case Rain
    case Clouds
    case Clear
    case Snow
    case Storm
    case Fog
}
