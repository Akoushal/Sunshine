//
//  UITableViewHeaderFooterView+Identifier.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/06.
//  Copyright © 2019 Unifa. All rights reserved.
//

import UIKit

extension UITableViewHeaderFooterView {
    static var uniqueIdentifier: String {
        return String(describing: self)
    }
}
