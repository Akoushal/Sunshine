//
//  WeatherViewModel.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/06.
//  Copyright © 2019 Unifa. All rights reserved.
//

import Foundation

class WeatherViewModel {
    
    private var weather: WeatherForecastList? {
        didSet {
            guard let wthr = weather else { return }
            self.setupWeather(with: wthr)
            self.didFinishFetch?()
        }
    }
    var error: Error? {
        didSet { self.showAlertClosure?() }
    }
    var isLoading: Bool = false {
        didSet { self.updateLoadingStatus?() }
    }
    
    private var dataService: DataService?
    
    // MARK: - Closures for callback, since we are not using the ViewModel to the View.
    var showAlertClosure: (() -> ())?
    var updateLoadingStatus: (() -> ())?
    var didFinishFetch: (() -> ())?
    var weatherList: [List] = [List]()
    
    // MARK: - Constructor
    init(dataService: DataService) {
        self.dataService = dataService
    }
    
    // MARK: - Network call
    func fetchWeather() {
        self.dataService?.requestFetchWeather(completion: { (weather, error) in
            if let error = error {
                self.error = error
                self.isLoading = false
                return
            }
            self.error = nil
            self.isLoading = false
            self.weather = weather
        })
    }
    
    // MARK: - UI Logic
    private func setupWeather(with weather: WeatherForecastList) {
        //Update ViewModel
        if let dataList = weather.list {
            self.weatherList = dataList
        }
    }
}
