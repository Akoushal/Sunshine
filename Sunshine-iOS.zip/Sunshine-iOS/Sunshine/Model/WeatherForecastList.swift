//
//  WeatherForecastList.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/06.
//  Copyright © 2019 Unifa. All rights reserved.
//

import Foundation
import Alamofire

struct Coord : Codable {
    let lat : Float?
    let lon : Float?
    
    enum CodingKeys: String, CodingKey {
        case lat = "lat"
        case lon = "lon"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        lat = try values.decodeIfPresent(Float.self, forKey: .lat)
        lon = try values.decodeIfPresent(Float.self, forKey: .lon)
    }
}

struct City : Codable {
    let coord : Coord?
    let country : String?
    let id : Int?
    let name : String?
    let population : Int?
    
    enum CodingKeys: String, CodingKey {
        case coord = "coord"
        case country = "country"
        case id = "id"
        case name = "name"
        case population = "population"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        coord = try values.decodeIfPresent(Coord.self, forKey: .coord)
        country = try values.decodeIfPresent(String.self, forKey: .country)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        population = try values.decodeIfPresent(Int.self, forKey: .population)
    }
}

struct Temp : Codable {
    let day : Float?
    let eve : Float?
    let max : Double?
    let min : Double?
    let morn : Float?
    let night : Float?
    
    enum CodingKeys: String, CodingKey {
        case day = "day"
        case eve = "eve"
        case max = "max"
        case min = "min"
        case morn = "morn"
        case night = "night"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        day = try values.decodeIfPresent(Float.self, forKey: .day)
        eve = try values.decodeIfPresent(Float.self, forKey: .eve)
        max = try values.decodeIfPresent(Double.self, forKey: .max)
        min = try values.decodeIfPresent(Double.self, forKey: .min)
        morn = try values.decodeIfPresent(Float.self, forKey: .morn)
        night = try values.decodeIfPresent(Float.self, forKey: .night)
    }
}

struct Weather : Codable {
    let id : Int?
    let main : String?
    let description : String?
    let icon : String?
    
    enum CodingKeys: String, CodingKey {
        
        case id = "id"
        case main = "main"
        case description = "description"
        case icon = "icon"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        main = try values.decodeIfPresent(String.self, forKey: .main)
        description = try values.decodeIfPresent(String.self, forKey: .description)
        icon = try values.decodeIfPresent(String.self, forKey: .icon)
    }
    
}

struct List : Codable {
    let clouds : Int?
    let deg : Int?
    let dt : Double?
    let humidity : Int?
    let pressure : Float?
    let rain : Float?
    let speed : Float?
    let temp : Temp?
    let weather : [Weather]?
    
    enum CodingKeys: String, CodingKey {
        case clouds = "clouds"
        case deg = "deg"
        case dt = "dt"
        case humidity = "humidity"
        case pressure = "pressure"
        case rain = "rain"
        case speed = "speed"
        case temp = "temp"
        case weather = "weather"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        clouds = try values.decodeIfPresent(Int.self, forKey: .clouds)
        deg = try values.decodeIfPresent(Int.self, forKey: .deg)
        dt = try values.decodeIfPresent(Double.self, forKey: .dt)
        humidity = try values.decodeIfPresent(Int.self, forKey: .humidity)
        pressure = try values.decodeIfPresent(Float.self, forKey: .pressure)
        rain = try values.decodeIfPresent(Float.self, forKey: .rain)
        speed = try values.decodeIfPresent(Float.self, forKey: .speed)
        temp = try values.decodeIfPresent(Temp.self, forKey: .temp)
        weather = try values.decodeIfPresent([Weather].self, forKey: .weather)
    }
}

struct WeatherForecastList : Codable {
    let city : City?
    let cnt : Int?
    let cod : String?
    let list : [List]?
    let message : Float?
    
    enum CodingKeys: String, CodingKey {
        case city = "city"
        case cnt = "cnt"
        case cod = "cod"
        case list = "list"
        case message = "message"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        city = try values.decodeIfPresent(City.self, forKey: .city)
        cnt = try values.decodeIfPresent(Int.self, forKey: .cnt)
        cod = try values.decodeIfPresent(String.self, forKey: .cod)
        list = try values.decodeIfPresent([List].self, forKey: .list)
        message = try values.decodeIfPresent(Float.self, forKey: .message)
    }
}

// MARK: - Alamofire response handlers
extension DataRequest {
    fileprivate func decodableResponseSerializer<T: Decodable>() -> DataResponseSerializer<T> {
        return DataResponseSerializer { _, response, data, error in
            guard error == nil else { return .failure(error!) }
            
            guard let data = data else {
                return .failure(AFError.responseSerializationFailed(reason: .inputDataNil))
            }
            return Result { try JSONDecoder().decode(T.self, from: data) }
        }
    }
    
    @discardableResult
    fileprivate func responseDecodable<T: Decodable>(queue: DispatchQueue? = nil, completionHandler: @escaping (DataResponse<T>) -> Void) -> Self {
        return response(queue: queue, responseSerializer: decodableResponseSerializer(), completionHandler: completionHandler)
    }
    
    @discardableResult
    func responseWeather(queue: DispatchQueue? = nil, completionHandler: @escaping (DataResponse<WeatherForecastList>) -> Void) -> Self {
        return responseDecodable(queue: queue, completionHandler: completionHandler)
    }
}
