//
//  Configuration.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/06.
//  Copyright © 2019 Unifa. All rights reserved.
//

import Foundation

struct Configuration {
    static let APIKey = "ce10471789a42da7c7fe792fef884ad6"
    static let BaseURL = "https://api.openweathermap.org/data/2.5/forecast"
    static let WeatherIconImageBaseURL = "http://openweathermap.org/img/w/"
    static let NumberOfDays = 16
    static let LocationInFocus = "Tokyo"
    static let ImageExtension = ".png"
    static let HeaderViewHeight = 215
}
