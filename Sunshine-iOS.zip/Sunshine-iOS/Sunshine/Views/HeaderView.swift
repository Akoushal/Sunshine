//
//  HeaderView.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/06.
//  Copyright © 2019 Unifa. All rights reserved.
//

import UIKit

class HeaderView: UITableViewHeaderFooterView {
    
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var maxTempLbl: UILabel!
    @IBOutlet weak var minTempLbl: UILabel!
    @IBOutlet weak var weatherConditionLbl: UILabel!
    @IBOutlet weak var iconImgView: UIImageView!
    private let utils = Utilities()
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setUp(with listObj: List?) {
        guard let weather = listObj?.weather?.first, let dt = listObj?.dt, let maxTemp = listObj?.temp?.max, let minTemp = listObj?.temp?.min else { return}
        maxTempLbl.text = utils.convertKelvinToDegreeCelsius(temp: maxTemp)
        minTempLbl.text = utils.convertKelvinToDegreeCelsius(temp: minTemp)
        dateLbl.text = utils.convertDateStampToDateString(dt: dt)
        if let main = weather.main {
            weatherConditionLbl.text = main
            let iconName = getLargeIconName(str: main)
            iconImgView.image = UIImage(named: iconName)
        }
    }
    
    func getLargeIconName(str: String) -> String {
        switch str {
        case WeatherCondition.Rain.rawValue:
            return "artRain"
        case WeatherCondition.Clouds.rawValue:
            return "artClouds"
        case WeatherCondition.Clear.rawValue:
            return "artClear"
        case WeatherCondition.Snow.rawValue:
            return "artSnow"
        case WeatherCondition.Storm.rawValue:
            return "artStorm"
        case WeatherCondition.Fog.rawValue:
            return "artFog"
        default:
            return ""
        }
    }
}
