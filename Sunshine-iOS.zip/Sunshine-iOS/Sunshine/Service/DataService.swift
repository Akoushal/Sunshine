//
//  DataService.swift
//  Sunshine
//
//  Created by Koushal, KumarAjitesh on 2019/03/06.
//  Copyright © 2019 Unifa. All rights reserved.
//

import Foundation
import Alamofire

struct DataService {
    
    // MARK: - Singleton
    static let shared = DataService()
    
    // MARK: - URL
    private var openWeatherUrl = "\(Configuration.BaseURL)/daily?q=\(Configuration.LocationInFocus)&appid=\(Configuration.APIKey)&cnt=\(Configuration.NumberOfDays)"
    
    // MARK: - Services
    func requestFetchWeather(completion: @escaping (WeatherForecastList?, Error?) -> ()) {
        Alamofire.request(openWeatherUrl).responseWeather { response in
            if let error = response.error {
                completion(nil, error)
                return
            }
            
            if let weather = response.result.value {
                completion(weather, nil)
                return
            }
        }
    }
}
